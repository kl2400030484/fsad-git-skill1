import java.util.Iterator;
import java.util.NoSuchElementException;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {

    private Item[] a;
    private int n;

    // construct an empty randomized queue
    public RandomizedQueue() {
        a = (Item[]) new Object[2];
        n = 0;
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return n == 0;
    }

    // return the number of items
    public int size() {
        return n;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException();
        if (n == a.length) resize(2 * a.length);
        a[n++] = item;
    }

    // remove and return a random item
    public Item dequeue() {
        if (isEmpty()) throw new NoSuchElementException();

        int r = StdRandom.uniformInt(n);
        Item item = a[r];
        a[r] = a[n - 1];
        a[n - 1] = null;
        n--;

        if (n > 0 && n == a.length / 4) resize(a.length / 2);
        return item;
    }

    // return a random item (do not remove)
    public Item sample() {
        if (isEmpty()) throw new NoSuchElementException();
        return a[StdRandom.uniformInt(n)];
    }

    // return an independent iterator in random order
    public Iterator<Item> iterator() {
        return new Iterator<Item>() {
            private final Item[] copy;
            private int i = 0;

            {
                copy = (Item[]) new Object[n];
                for (int j = 0; j < n; j++) copy[j] = a[j];
                StdRandom.shuffle(copy);
            }

            public boolean hasNext() {
                return i < copy.length;
            }

            public Item next() {
                if (!hasNext()) throw new NoSuchElementException();
                return copy[i++];
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    private void resize(int capacity) {
        Item[] temp = (Item[]) new Object[capacity];
        for (int i = 0; i < n; i++) temp[i] = a[i];
        a = temp;
    }

    // unit testing
    public static void main(String[] args) {
        RandomizedQueue<Integer> rq = new RandomizedQueue<>();
        rq.enqueue(1);
        rq.enqueue(2);
        rq.enqueue(3);

        System.out.println(rq.dequeue());
        System.out.println(rq.sample());
    }
}
